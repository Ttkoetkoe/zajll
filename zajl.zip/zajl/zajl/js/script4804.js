﻿var v = '1.9.4.16';
var currentLang = 'ar';
if (window.location.toString().toLowerCase().indexOf(window.location.host + '/en') > -1) {
    currentLang = 'en';
}
function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
function IsNullString(val) {
    if (val === null) {
        return '';
    }
    return val;
}
$(function () {
    var loadTemplate = '/Templates/';
    if (window.location.toString().toLowerCase().indexOf(window.location.host + '/en') > -1) {
        loadTemplate = '/en/Templates/';
    }

    $('#htmlTemplateHeader').load(loadTemplate + 'header.html?v=' + v, function () { });
    $('#htmlTemplateFooter').load(loadTemplate + 'footer.html?v=' + v, function () { });


    $("#htmlTemplateHeader").on("click", "a#btnLang", function (e) {
        e.preventDefault();
        var lang = $(this).find('span').text();
        lang = lang.toString().trim();
        var newURL;
        if (lang === 'English') {
            newURL = window.location.toString().toLowerCase().replace(window.location.host, window.location.host + '/en');
        } else {
            newURL = window.location.toString().toLowerCase().replace(window.location.host + '/en', window.location.host);
        }
        window.location = newURL;
        return false;
    });
    //$('#btnContactUs').click(function (e) {
    //    e.preventDefault();
    //    $('#lblError').text('');
    //    $('#lblError').hide();


    //    var x = validateGroups('.formPanel ');
    //    if (x == false) {
    //        // $('#lblError').slideDown('slow');
    //        return false;
    //    }

    //    var fields = {};

    //    fields['txtFullName'] = $('#txtFullName').val();
    //    fields['txtMobile'] = $('#txtMobileNumber').val();
    //    fields['txtEmail'] = $('#txtEmail').val();
    //    fields['txtDetails'] = $('#txtDetails').val();
    //    fields['lang'] = currentLang;

    //    console.log(JSON.stringify(fields));
    //    $.ajax({
    //        type: "POST",
    //        url: 'https://site.zajil-express.com/api/Shipment/ContactUs',
    //        data: fields,
    //        dataType: 'json',

    //        success: function (data) {
    //            $("body").mLoading('hide');
    //            if (data.ExceptionError != null) {
    //                $('#lblError').text(data.ExceptionError).slideDown('slow');
    //                return;
    //            }
    //            $('#RequestNo').show();
    //            $('#TicketNumber').text(data.RequestNo)

    //            $('#RequestNo').show();
    //            $('#TicketNumber').text(data.RequestNo)

    //            $('#lnkTrack').prop('href', 'https://tra.zajil-express.com/tracking.aspx?id=' + data.RequestNo + '&mobile=00966' + fields['txtMobile'].toString().substr(1) + '&type=pkp');

    //            $('.formPanel').hide();
    //            $('#pnlResult').slideDown('slow');
    //        },
    //        error: function (result) {
    //            $("body").mLoading('hide');
    //        }
    //        , complete: function () {
    //            $("body").mLoading('hide');
    //        }
    //    });


    //});

});