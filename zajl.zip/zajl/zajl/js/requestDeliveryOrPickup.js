﻿//var currentLang = 'ar';
//if (window.location.toString().toLowerCase().indexOf(window.location.host + '/en') > -1) {
//    currentLang = 'en';
//}
$(function () {
    var fields = {};
    fields['lang'] = currentLang;
    $.ajax({
        type: "GET",
        url: 'https://site.zajil-express.org/api/Shipment/getCitiesList',
        //url: 'http://localhost:3116/api/Shipment/getCitiesList',
        data: fields,
        dataType: 'json',

        success: function (data) {
            // $(".panelGrey").mLoading('hide');
            if (data.ExceptionError != null) {
                if (currentLang == "en") {
                    $('#lblErrorRequestDelivery').text('Failure occurred in loading cities. Please try after sometime');
                    $('#lblErrorRequestDelivery').slideDown('slow');
                }
                else {
                    $('#lblErrorRequestDelivery').text('حدث فشل في تحميل المدن. يرجى المحاولة بعد مرور بعض الوقت');
                    $('#lblErrorRequestDelivery').slideDown('slow');
                }
                return;
            }

            for (var i = 0; i < data.Cities.length; i++) {
                var pnl = '<option value="' + IsNullString(data.Cities[i]['value']) + '">' + IsNullString(data.Cities[i]['value']) + '</option>';
                $(pnl).appendTo('select#txtCity');
            }
        }
    });

$('#btnDelivery').click(function (e) {
    e.preventDefault();
    $('#lblErrorRequestDelivery').text('');
    $('#lblErrorRequestDelivery').hide();


    if (($('#txtService').val() === '' || $('#txtService').val() === undefined) || ($('#txtShipmentNumber').val() === '' || $('#txtShipmentNumber').val() === undefined) || ($('#txtFullName').val() === '' || $('#txtFullName').val() === undefined) || ($('#txtMobileNumber').val() === '' || $('#txtMobileNumber').val() === undefined)  
        || ($('#txtEmail').val() === '' || $('#txtEmail').val() === undefined) || ($('#txtFullAddress').val() === '' || $('#txtFullAddress').val() === undefined) || ($('#txtCity').val() === '' || $('#txtCity').val() === undefined)) {
        if (currentLang === "en") {
            $('#lblErrorRequestDelivery').text('Please enter the above details');
            $('#lblErrorRequestDelivery').slideDown('slow');
        }
        else {
            $('#lblErrorRequestDelivery').text('الرجاء إدخال التفاصيل الكاملة');
            $('#lblErrorRequestDelivery').slideDown('slow');
        }
        return;
    }

    //To Validate Email address
    const mail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!mail.test($('#txtEmail').val())) {
        if (currentLang === "en") {
            $('#lblErrorRequestDelivery').text('Please enter a valid email address');
            $('#lblErrorRequestDelivery').slideDown('slow');
        }
        else {
            $('#lblErrorRequestDelivery').text('رجاء قم بإدخال بريد الكتروني صحيح');
            $('#lblErrorRequestDelivery').slideDown('slow');
        }
        return;
    }

    var mobileN = /^\d{10}$/;
    if (!mobileN.test($('#txtMobileNumber').val())) {
        // value is  not ok, show below message
        if (currentLang === "en") {
            $('#lblErrorRequestDelivery').text('Please enter a valid mobile number');
            $('#lblErrorRequestDelivery').slideDown('slow');
        }
        else {
            $('#lblErrorRequestDelivery').text('الرجاء إدخال رقم جوال صحيح');
            $('#lblErrorRequestDelivery').slideDown('slow');
        }
        return;
    } 

    $('#btnDelivery').prop("disabled", true);
    $(".body").mLoading();
    var fields = {};
    fields['txtService'] = $('#txtService').val();
    fields['txtShipmentNumber'] = $('#txtShipmentNumber').val();
    fields['txtFullName'] = $('#txtFullName').val();
    fields['txtMobileNumber'] = $('#txtMobileNumber').val();
    fields['txtEmail'] = $('#txtEmail').val();    
    fields['txtFullAddress'] = $('#txtFullAddress').val();
    fields['txtCity'] = $('#txtCity').val();
    fields['txtDetails'] = $('#txtDetails').val();
    fields['lang'] = currentLang;

    $.ajax({
        async: true,
        type: "POST",
        url: 'https://site.zajil-express.org/api/Shipment/SendMailRequestDelivery',
        data: fields,
        dataType: "json",

        success: function (data) {
            $(".body").mLoading('hide');
            if (data.status === 1) {
                if (fields['lang'] === "en") {
                    $('#lblResultRequestDelivery').text('Dear Customer, Your request was received successfully and our Customer Service team will follow up it. Thank you for reaching out to us.');
                    $('#lblResultRequestDelivery').slideDown('slow');
                }
                else {
                    $('#lblResultRequestDelivery').text('عزيزي العميل ، تم استلام طلبك بنجاح وسيقوم فريق خدمة العملاء لدينا بمتابعته. شكر لتواصلك معنا');
                    $('#lblResultRequestDelivery').slideDown('slow');
                }
                $('#txtService').val('');
                $('#txtShipmentNumber').val('');
                $('#txtFullName').val('');
                $('#txtMobileNumber').val('');
                $('#txtEmail').val('');                
                $('#txtFullAddress').val('');
                $('#txtCity').val('');
                $('#txtDetails').val('');
                $('#btnDelivery').prop("disabled", false);
            }
            else {
                $(".body").mLoading('hide');
                if (fields['lang'] === "en") {
                    $('#lblErrorRequestDelivery').text('Failure occured in processing your request. Please try after sometime' + data.result);
                    $('#lblErrorRequestDelivery').slideDown('slow');
                }
                else {
                    $('#lblErrorRequestDelivery').text('حدث فشل في معالجة طلبك. يرجى المحاولة بعد مرور بعض الوقت' + data.result);
                    $('#lblErrorRequestDelivery').slideDown('slow');
                }
                $('#txtService').val('');
                $('#txtShipmentNumber').val('');
                $('#txtFullName').val('');
                $('#txtMobileNumber').val('');
                $('#txtEmail').val('');
                $('#txtFullAddress').val('');
                $('#txtCity').val('');
                $('#txtDetails').val('');
                Console.Error.WriteLine(response);

            }

        },
        error: function (result) {
            $(".body").mLoading('hide');
            if (fields['lang'] === "en") {
                $('#lblErrorRequestDelivery').text('Failure occured in processing your request. Please try after sometime' + data.result);
                $('#lblErrorRequestDelivery').slideDown('slow');
            }
            else {
                $('#lblErrorRequestDelivery').text('حدث فشل في معالجة طلبك. يرجى المحاولة بعد مرور بعض الوقت' + data.result);
                $('#lblErrorRequestDelivery').slideDown('slow');
            }
        },
        complete: function () {
            $("body").mLoading('hide');
        }

    });
});
});
